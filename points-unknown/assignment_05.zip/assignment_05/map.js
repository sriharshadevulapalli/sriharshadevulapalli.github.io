mapboxgl.accessToken = 'pk.eyJ1Ijoic2QzMDc2IiwiYSI6ImNremJyNW91bDJnZXAybm5rcWtwcGc2dnYifQ.YFcTZCJsTE_xWygvDg0aqw';
// const bounds = [
//   [50, 60], // Southwest coordinates
//   [150, -0] // Northeast coordinates
//   ];
var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/sd3076/cl4jbdc8b004p14qs5v04mp01',
    zoom: 5,
    maxZoom: 6,
    minZoom: 4,
    center: [-119,37],
    // projection: 'equalEarth',
    // maxBounds: bounds,

});

map.on("load", function () {
  map.addLayer({
    id: "world_boundaries",
    type: "line",
    source: {
      type: "geojson",
      data: "data/newfile.geojson",
    },
    paint: {
      "line-color": "#e25822",
      "line-width": 0.5,
    },
  },
// Here's where we tell Mapbox where to slot this new layer
);
  map.addLayer({
    id: "fires",
    type: "fill",
    source: {
      type: "geojson",
      data: "data/newfile.geojson",
    },
    'paint': {
      'fill-color': "black",
    }
    // 'paint': {
    //   'fill-color': [
    //   'interpolate',
    //   ['linear'],
    //   ['get', 'Mean BP'],
    //   0,
    //   '#F2F12D',
    //   0.0001,
    //   '#EED322',
    //   0.0005,
    //   '#E6B71E',
    //   0.0010,
    //   '#DA9C20',
    //   0.0015,
    //   '#CA8323',
    //   ]},
  }, "waterway-label");

});

map.on("click", "world_fill", function (e) {
  var country = e.features[0].properties.NAMELSAD_x;
  var score = e.features[0].properties["Mean BP"];
  country = country.toUpperCase();
  new mapboxgl.Popup()
    .setLngLat(e.lngLat)
    .setHTML(
      "<h4><b>" +
        country + 
        "</b></h4><p>WJP Rule of Law Index 2021 Score: <b>" +
        score +
        " </b></p>"
    )
    .addTo(map);
});

map.on("mouseenter", "world_fill", function () {
  map.getCanvas().style.cursor = "pointer";
});

map.on("mouseleave", "world_fill", function () {
  map.getCanvas().style.cursor = "";
});